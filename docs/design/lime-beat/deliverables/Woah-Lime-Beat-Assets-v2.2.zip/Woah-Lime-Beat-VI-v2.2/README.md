# Woah Lime Beat VI v2.2

2026-11-04。当前正式方向：青柠节拍。此包替代 Quiet Frame v1.1 的主视觉交付。

先阅读 Woah-Lime-Beat-VI-v2.2.pdf。亮色采用 Chalk 浅白底与 Lime 青柠主标识；Ink / Chalk 为辅助单色版本。首页字标为 24sp、W 宽 28dp，卡片渐变收为浅青柠 #F0F6DA。标识保留原 W 几何，没有旧薄荷主 Logo。

assets/logo：转轮廓 SVG；assets/icons：系统图标与源图层；assets/photography：新封面；assets/applications：真机首页与海报；assets/tokens：JSON/CSS；assets/fonts：授权字体与原许可证。

产品界面只显示 Woah，正式中文名为舞哇。人物标记遵循 segmentation mask；封面与品牌色不代表保护已完成。

首页左右滑卡、整卡点击、露边与分页不变。基线采用统一 Strut 行高。图标、启动页与应用均使用新色系。

重建脚本：source/build_vi.py。依赖 Python 3、reportlab、fonttools、Pillow、PyMuPDF。字体按原许可证随包保留；PDF 嵌入所需子集。仓库中从 docs/design/lime-beat/source/build_vi.py 重建，独立包也保留必需的图片、Token、字体和源代码。

iOS 尚未在本轮设备运行；真实视频保护 / 同步 / 导出以具体工作流检查为准。旧版设备检查不能作为本版签核。
